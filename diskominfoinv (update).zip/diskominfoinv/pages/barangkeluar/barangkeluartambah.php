<div id="atas" class="row mb-3">
    <div class="col">
        <div class="row">
            <div class="col-md-6">
                <h3>Tambah Data Barang Keluar</h3>
            </div>
            <div class="col-md-6">
                <a href="?page=barangkeluar" class="btn btn-primary btn-sm float-end">
                    <i class="fa fa-arrow-circle-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>
</div>
<div id="tengah">
    <div class="col">
        <?php
        if (isset($_POST['simpan_button'])) {
            $tgl_klr = $_POST['tgl_klr'];
            $kode_brg = $_POST['kode_brg'];
            $nama_brg = $_POST['nama_brg'];
            $jml = $_POST['jml'];
            $satuan = $_POST['satuan'];
            $checkSQL = "SELECT * FROM barang_keluar WHERE tgl_klr = '$tgl_klr'";
            $resultCheck = mysqli_query($koneksi, $checkSQL);
            $sudahAda = (mysqli_num_rows($resultCheck) > 0) ? true : false;
            if ($sudahAda) {
        ?>
                <div class="alert alert-danger" role="alert">
                    <i class="fa fa-exclamation-circle"></i>
                    Data Barang Keluar sama sudah ada
                </div>
    <div class="col">
                    </div>
                <?php
            } else {
                $insertSQL = "INSERT INTO barang_keluar SET tgl_klr='$tgl_klr', 
                kode_brg='$kode_brg',
                nama_brg='$nama_brg',
                jml='$jml',
                satuan='$satuan'";
                $result = mysqli_query($koneksi, $insertSQL);
                if (!$result) {
                ?>
                    <div class="alert alert-danger" role="alert">
                        <i class="fa fa-exclamation-circle"></i>
                        <?= mysqli_error($koneksi) ?>
                    </div>
                <?php
                } else {
                ?>
                    <div class="alert alert-success" role="alert">
                        <i class="fa fa-check-circle"></i>
                        Data Barang Keluar Berhasil Ditambahkan
                    </div>
                    
        <?php
                }
            }
        }
        ?>
    </div>
</div>
<div id="bawah" class="row">
    <div class="col">
        <div class="card px-3 py-3">
            <form action="" method="post">
                <div class="mb-3">
                    <label for="tgl_klr">Tanggal Keluar</label>
                    <input type="text" class="form-control" name="tgl_klr" required>
                </div>
                <div class="mb-3">
                    <label for="kode_brg">Kode Barang</label>
                    <input type="text" class="form-control" name="kode_brg" required>
                <div class="mb-3">
                    <label for="nama_brg">Nama Barang</label>
                    <input type="text" class="form-control" name="nama_brg" required>
                </div>
                <div class="mb-3">
                    <label for="jml">Jumlah</label>
                    <input type="text" class="form-control" name="jml" required>
                </div>
                <div class="mb-3">
                    <label for="satuan">Satuan</label>
                    <input type="text" class="form-control" name="satuan" required>
                </div>
                <div class="col mb-3">
                    <button class="btn btn-success" type="submit" name="simpan_button">
                        <i class="fas fa-save"></i>
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
</script>