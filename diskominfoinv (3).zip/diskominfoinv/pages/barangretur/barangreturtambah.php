<div id="atas" class="row mb-3">
    <div class="col">
        <div class="row">
            <div class="col-md-6">
                <h3>Tambah Data Barang Retur</h3>
            </div>
            <div class="col-md-6">
                <a href="?page=barangreturdata" class="btn btn-primary btn-sm float-end">
                    <i class="fa fa-arrow-circle-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>
</div>
<div id="tengah">
    <div class="col">
        <?php
        if (isset($_POST['simpan_button'])) {
            $nama_barang = $_POST['nama_barang'];
            $kode = $_POST['kode'];
            $tanggal = $_POST['tanggal'];
            $jml = $_POST['jml'];
            $ket = $_POST['ket'];
            $checkSQL = "SELECT * FROM barang_retur WHERE nama_barang = '$nama_barang'";
            $resultCheck = mysqli_query($koneksi, $checkSQL);
            $sudahAda = (mysqli_num_rows($resultCheck) > 0) ? true : false;
            if ($sudahAda) {
        ?>
                <div class="alert alert-danger" role="alert">
                    <i class="fa fa-exclamation-circle"></i>
                    Nama Barang sama sudah ada
                </div>
    <div class="col">
                    </div>
                <?php
            } else {
                $insertSQL = "INSERT INTO barang_retur SET nama_barang='$nama_barang', 
                kode='$kode',
                tanggal='$tanggal',
                jml='$jml',
                ket='$ket'";
                $result = mysqli_query($koneksi, $insertSQL);
                if (!$result) {
                ?>
                    <div class="alert alert-danger" role="alert">
                        <i class="fa fa-exclamation-circle"></i>
                        <?= mysqli_error($koneksi) ?>
                    </div>
                <?php
                } else {
                ?>
                    <div class="alert alert-success" role="alert">
                        <i class="fa fa-check-circle"></i>
                        Data Barang Retur Berhasil Ditambahkan
                    </div>
                    
        <?php
                }
            }
        }
        ?>
    </div>
</div>
<div id="bawah" class="row">
    <div class="col">
        <form action="" method="post">
            <div class="card px-3 py-3">
                <div class="row">
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="id">Tanggal Barang Retur</label>
                            <input type="date" name="tanggal" class="form-control" required value="<?= date("Y-m-d") ?>">
    </div>
    </div>
    <div class="col">
        <div class="card px-3 py-3">
            <form action="" method="post">
                <div class="mb-3">
                    <label for="nama_barang">Nama Barang</label>
                    <input type="text" class="form-control" name="nama_barang" required>
                </div>
                <div class="mb-3">
                    <label for="kode">Kode</label>
                    <input type="text" class="form-control" name="kode" required>
                </div>
                <div class="mb-3">
                    <label for="jml">Jumlah</label>
                    <input type="text" class="form-control" name="jml" required>
                </div>
                <div class="mb-3">
                    <label for="ket">Keterangan</label>
                    <input type="text" class="form-control" name="ket" required>
                </div>
                <div class="col mb-3">
                    <button class="btn btn-success" type="submit" name="simpan_button">
                        <i class="fas fa-save"></i>
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
</script>