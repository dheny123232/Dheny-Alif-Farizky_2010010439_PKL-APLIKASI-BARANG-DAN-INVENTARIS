<div id="atas" class="row mb-3">
    <div class="col">
        <div class="row">
            <div class="col-md-6">
                <h3>Ubah Data Barang Keluar</h3>
            </div>
            <div class="col-md-6">
                <a href="?page=barangkeluardata" class="btn btn-primary btn-sm float-end">
                    <i class="fa fa-arrow-circle-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>
</div>
<div id="tengah">
    <div class="col">
        <?php
        if (isset($_POST['simpan_button'])) {
            $id = $_POST['id'];
            $tgl_klr = $_POST['tgl_klr'];
            $kode_brg = $_POST['kode_brg'];
            $nama_brg = $_POST['nama_brg'];
            $jml = $_POST['jml'];
            $checkSQL = "SELECT * FROM barang_keluar WHERE kode_brg = '$kode_brg' AND id!=$id";
            $resultCheck = mysqli_query($koneksi, $checkSQL);
            $sudahAda = (mysqli_num_rows($resultCheck) > 0) ? true : false;
            if ($sudahAda) {
        ?>
                <div class="alert alert-danger" role="alert">
                    <i class="fa fa-exclamation-circle"></i>
                    Kode Barang Keluar Sudah Ada
                </div>
                <?php
            } else {
                $updateSQL = "UPDATE barang_keluar SET tgl_klr='$tgl_klr', 
                kode_brg ='$kode_brg',
                nama_brg='$nama_brg', 
                jml='$jml' 
                WHERE id=$id";
            $result = mysqli_query($koneksi, $updateSQL);
            if (!$result) {
        ?>
                <div class="alert alert-danger" role="alert">
                    <i class="fa fa-exclamation-circle"></i>
                    <?= mysqli_error($koneksi) ?>
                </div>
            <?php
                } else {
                ?>
                    <div class="alert alert-success" role="alert">
                        <i class="fa fa-check-circle"></i>
                        Data Berhasil Diubah
                    </div>
        <?php
                }
            }
        }

        $id = $_GET['id'];
        $selectSQL = "SELECT * FROM barang_keluar WHERE id=$id";
        $result = mysqli_query($koneksi, $selectSQL);
        if (!$result || mysqli_num_rows($result) == 0) {
            echo "<meta http-equiv='refresh' content='0;url=?page=barangkeluardata'>";
        } else {
            $row = mysqli_fetch_assoc($result);
        }
        ?>
    </div>
    <div id="bawah" class="row">
    <div class="col">
        <form action="" method="post">
            <input type="hidden" name="id" value="<?= $id ?>">
            <div class="card px-3 py-3">
                <div class="row">
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="id">Tanggal Keluar</label>
                            <input type="date" name="tgl_klr" class="form-control" required value="<?= $row['tgl_klr'] ?>">
                        </div>
</div>
<div id="bawah" class="row">
    <div class="col">
        <div class="card px-3 py-3">
            <form action="" method="post">
                <div class="mb-3">
                    <label for="id">ID</label>
                    <input type="text" class="form-control" name="id" value="<?= $row['id'] ?>" readonly>
                </div>
                </div>
                <div class="mb-3">
                    <label for="kode_brg">Kode Barang Keluar</label>
                    <input type="text" class="form-control" name="kode_brg" value="<?= $row['kode_brg'] ?>" required>
                 <div class="mb-3">
                    <label for="nama_brg">Nama Barang Keluar</label>
                    <input type="text" class="form-control" name="nama_brg" value="<?= $row['nama_brg'] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="">Jumlah</label>
                    <input type="text" class="form-control" name="jml" value="<?= $row['jml'] ?>" required>
                </div>
                <div class="col mb-3">
                    <button class="btn btn-success" type="submit" name="simpan_button">
                        <i class="fas fa-save"></i>
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
</script>